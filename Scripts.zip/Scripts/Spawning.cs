﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Spawning : MonoBehaviour
{
    public PlayerHealth playerHealth;       // Reference to the player's heatlh.
    public GameObject enemy;                // The enemy prefab to be spawned.
    public float spawnTime = 3f;            // How long between each spawn.
    public Transform[] spawnPoints;         // An array of the spawn points this enemy can spawn from.
    public int spawnAmount = 3;
    public int spawnCount = 3;
    public int levelCounter = 0;
    public bool levelStart;
    public static int killCount;
    public int killDisplay;
    public Text Round;


    void Start()
    {
        Round.text = "Wave: " + levelCounter.ToString(); 
        Level();
    }

    private void Update()
    {
        killDisplay = killCount;
        if (levelStart == true)
        {
            // Call the Spawn function after a delay of the spawnTime and then continue to call after the same amount of time.
            InvokeRepeating("Spawn", 5, spawnTime);
            levelStart = false;
        }

        if (killCount == spawnAmount)
        {
            Level();
        }
    }

    void Spawn()
    {
        levelStart = false;
        // If the player has no health left...
        if (playerHealth.currentHealth <= 0f)
        {
            // ... exit the function.
            CancelInvoke();
        }

        // Find a random index between zero and one less than the number of spawn points.
        int spawnPointIndex = Random.Range(0, spawnPoints.Length);

        // Create an instance of the enemy prefab at the randomly selected spawn point's position and rotation.
        Instantiate(enemy, spawnPoints[spawnPointIndex].position, spawnPoints[spawnPointIndex].rotation);

        spawnCount--;

        if (spawnCount <= 0)
        {
            CancelInvoke();
        }
    }

    void Level()
    {
        levelStart = false;
        killCount = 0;
        levelCounter += 1;
        spawnAmount = (levelCounter + 5);
        spawnCount = spawnAmount;
        Round.text = "Wave: " + levelCounter.ToString();
        levelStart = true;
        return;
    }
}