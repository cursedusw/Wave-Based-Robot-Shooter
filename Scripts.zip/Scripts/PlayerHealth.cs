﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using EZCameraShake;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
    public float startingHealth = 100;                            // The amount of health the player starts the game with.
    public float currentHealth;                                   // The current health the player has.
    public Slider healthSlider;                                 // Reference to the UI's health bar.                               // The audio clip to play when the player dies.
    public float flashSpeed = 5f;                               // The speed the damageImage will fade at.

    public float startingShild = 100;                            // The amount of health the player starts the game with.
    public float currentShild;                                   // The current health the player has.
    public Slider shildSlider;

    public float reginShild;
    public float reginTime = 3;


    Animator anim;                                              // Reference to the Animator component.
    AudioSource playerAudio;                                    // Reference to the AudioSource component.
    bool isDead;                                                // Whether the player is dead.
    public bool damaged;                                               // True when the player gets damaged.


    void Awake()
    {
        // Setting up the references.
        anim = GetComponent<Animator>();
        playerAudio = GetComponent<AudioSource>();

        // Set the initial health of the player.
        currentHealth = startingHealth;
        currentShild = 0;
        damaged = true;
    }


    void Update()
    {
        reginShild += Time.deltaTime;
        healthSlider.value = currentHealth;
        if (Input.GetKeyDown(KeyCode.Alpha1) && PlayerInvantory.points >= 20)
        {
            if (currentHealth <= 90)
            { 
                PlayerInvantory.points -= 20;
                currentHealth += 10;
            }
            else if (currentHealth > 90 && currentHealth < 100)
            {
                currentHealth = startingHealth;
            }
        }

        shildSlider.value = currentShild;


        if(damaged == true && currentShild!= startingShild && reginShild >= reginTime)
        {
            ShildRegin();
        }

        

    }

    public void TakeDamage(float amount)
    {
        damaged = true;
        reginShild = 0;
        CameraShaker.Instance.ShakeOnce(2f, 2f, .1f, 1f);

        if (currentShild > 0)
        {
            currentShild -= amount;
        }

        if (currentShild <= 0)
        {
            currentHealth -= amount;
        }
        

        // Set the health bar's value to the current health.
        healthSlider.value = currentHealth;


        // If the player has lost all it's health and the death flag hasn't been set yet...
        if (currentHealth <= 0 && !isDead)
        {
            // ... it should die.
            Death();
        }
    }


    void ShildRegin()
    {
        
        if (currentShild >= startingShild)
        {
            damaged = false;
        }
        currentShild += 10 * Time.deltaTime;
    }


    void Death()
    {
        // Set the death flag so this function won't be called again.
        isDead = true;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = (true);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}