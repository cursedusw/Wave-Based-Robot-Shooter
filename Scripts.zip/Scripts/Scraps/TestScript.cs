﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEditor;

public class TestScript : MonoBehaviour
{

    public float speed = 5, sprintSpeed = 8, turnSpeed = 150,
                 mouseDeadzone = .01f, jumpForce = 2;
    //public float minLook = -85, maxLook = 85;
    public bool invertXAxis = false, invertYAxis = true, 
                isSprinting = false;
    public Transform cam;
    public Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked; //locks the cursor in the game view
        cam = Camera.main.transform; //finds the main camera and retrieves it's transform information to manipulate later.
        rb = GetComponent<Rigidbody>(); //get the Rigidbody to apply forces too later. 
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))//if the player presses Escape
        {
            Cursor.lockState = CursorLockMode.None; //Unlock the cursor in the game view
        }

        if (Input.GetKeyDown(KeyCode.LeftShift)) //sprint button is pushed
        {
            isSprinting = true; //we are sprinting
        }
        if (Input.GetKeyUp(KeyCode.LeftShift))// sprint button is lifted
        {
            isSprinting = false; //we are now walking.
        }

        float mouseX = Input.GetAxis("Mouse X") * turnSpeed * 
                       Time.deltaTime; //get left/right mouse input
        float mouseY = Input.GetAxis("Mouse Y") * turnSpeed * 
                       Time.deltaTime; //get up/down mouse input

        if (Mathf.Abs(mouseX) > mouseDeadzone)
        {
            if (invertXAxis) //if player wants an inverted axis
                mouseX *= -1; //reverse the output. Ex. 5 becomes -5

            transform.Rotate(new Vector3(0, mouseX, 0)); //rotate the player on the y Axis to turn.
        }

        if (Mathf.Abs(mouseY) > mouseDeadzone)
        {
            if (invertYAxis)
                mouseY *= -1;

            cam.Rotate(new Vector3(mouseY, 0, 0)); //rotate the camera only for up and down
        }
    }

    private void FixedUpdate() //anything that will effect physics we want to calculate here for better accuracy. 
    {
        float curSpeed = speed;

        if (isSprinting)
            curSpeed = sprintSpeed;

        if (Input.GetKey(KeyCode.W))
        {
            transform.position += transform.forward * curSpeed * Time.deltaTime; //move player in the direction of forward
        }

        if (Input.GetKey(KeyCode.A))
        {
            transform.position += -transform.right * curSpeed * Time.deltaTime; //move player in the direction of negative right (left)
        }

        if (Input.GetKey(KeyCode.S))
        {
            transform.position += -transform.forward * curSpeed * Time.deltaTime; //move player in the direction of negative forward (back)
        }

        if (Input.GetKey(KeyCode.D))
        {
            transform.position += transform.right * curSpeed * Time.deltaTime; //move player in the direction of right
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(Vector3.up*jumpForce*10); //apply a force in the direction of 'up' to jump. 
        }
    }

}
