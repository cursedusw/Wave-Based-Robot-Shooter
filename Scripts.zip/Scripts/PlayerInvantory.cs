﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PlayerInvantory : MonoBehaviour
{
    public static int points;
    public Text pointsDisplay;
    
    void Start()
    {
        points = 0;
        PointsUpdate();
    }

    private void Update()
    {
        PointsUpdate();
        
    }

    public void PointsUpdate()
    {
        pointsDisplay.text = points.ToString()+" :Points";
    }
}
