﻿using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class ai_onslought : MonoBehaviour
{

    public float lookRadius = 10f;

    Transform target;
    NavMeshAgent agent;
    public float range = 100f;
    public bool fallow;
    public float timeToFallow = 5f;
    public float shootCount;
    private float muzzleFlash = 0f;
    public float seeTime = 2;

    // Start is called before the first frame update
    void Start()
    {
        target = PlayerManager.instance.player.transform;
        agent = GetComponent<NavMeshAgent>();
        fallow = true;
    }

    // Update is called once per frame
    void Update()
    {
        

        if (fallow)
        {
            Persue();
        }
    }

    void Persue()
    {
        // makes the ai go to the player
        float distance = Vector3.Distance(target.position, transform.position);
        agent.SetDestination(target.position);

            FaceTarget();
    }

    void FaceTarget()
    {
        //makes the ai look at the player
        Vector3 direction = (target.position - transform.position).normalized;
        transform.LookAt(target);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, lookRadius);
    }
}

