﻿
using System.Collections;
using UnityEngine;
using EZCameraShake;
using UnityEngine.UI;
public class gun : MonoBehaviour
{
    public float damage = 10f;
    public float range = 100f;
    public int fireMode = 1;
    public float normalSpread = 0.05f;
    public float impactForce = 30f;
    public float fireRate = 15f;

    public float meleeDamage = 50f;

    public Text ammoText;

    public bool fire = true;

    public int ammoNeeded;
    public static int gelPouch;
    public int pointDisplay;
    public static int currentAmmo;
    public float reloadTime = 1.05f;
    private bool isReloading = false;
    public int clip;

    public GameObject fpsCam;
    public ParticleSystem muzzleFlash;
    public GameObject impactEffect;
    public Recoil recoilRotation;

    private float nextTimeToFire = 0f;

    public Animator animator;
    public AudioSource gunShoot;

    void OnEnable()
    {
        ammoNeeded = clip;
        isReloading = false;
        animator.SetBool("reloading", false);
        animator.SetBool("running", false);
        animator.SetBool("aiming", false);
        animator.SetBool("melee", false);
    }

    void Start()
    {
        currentAmmo = clip;
        AmmoUpdate();
        gunShoot = GetComponent<AudioSource>();
    }

    void Update()
    {
        pointDisplay = PlayerInvantory.points;

        if (isReloading)
        {
            return;
        }

        if (currentAmmo < clip && Input.GetKeyDown(KeyCode.R) && PlayerInvantory.points > 0)
        {
            StartCoroutine(Reload());
            return;
        }

        if (currentAmmo <= 0 && PlayerInvantory.points > 0)
        {
            StartCoroutine(Reload());
            return;
        }

            if (fireMode > 0)
        {
            if (Input.GetKeyDown(KeyCode.Mouse0) && Time.time >= nextTimeToFire && currentAmmo > 0 && fire is true)
            {
                nextTimeToFire = Time.time + 1f / fireRate;
                Shoot();
            }
        }
        else
        {
            if (Input.GetKey(KeyCode.Mouse0) && Time.time >= nextTimeToFire && currentAmmo > 0 && fire is true)
            {
                nextTimeToFire = Time.time + 1f / fireRate;
                Shoot();
                
            }
        }

        if (Input.GetKey(KeyCode.LeftShift) && Input.GetKey(KeyCode.W) && PlayerControls.isGrounded == true)
        {
            animator.SetBool("running", true);
            fire = false;
        }
        else
        {
            animator.SetBool("running", false);
            fire = true;
        }

        if (Input.GetKeyDown(KeyCode.Mouse1) && !isReloading)
        {
            recoilRotation.recoilSpeed /= 3;
            animator.SetBool("aiming", true);
            normalSpread /= 4;
        }
        if(Input.GetKeyUp(KeyCode.Mouse1))
        {
            animator.SetBool("aiming", false);
            normalSpread *= 4;
            recoilRotation.recoilSpeed *= 3;
        }

        if (Input.GetKeyDown(KeyCode.F))
        {
            StartCoroutine(Melee());
        }
    }

    void Shoot()
    {
        gunShoot.Play();

        CameraShaker.Instance.ShakeOnce(2f, 2f, .1f, 1f);

        recoilRotation.recoil += 0.1f;

        muzzleFlash.Play();

        currentAmmo--;

        RaycastHit hit;

        Vector3 direction = fpsCam.transform.forward * Time.deltaTime *100; // Bullet Spread
        direction.x += Random.Range(-normalSpread, normalSpread);
        direction.y += Random.Range(-normalSpread, normalSpread);
        direction.z += Random.Range(-normalSpread, normalSpread);

        //recoilRotation.transform.localRotation = Quaternion.Lerp(Quaternion.Euler(recoilRotation.transform.localEulerAngles), Quaternion.Euler(direction), Time.deltaTime * 100);
        recoilRotation.transform.Rotate(new Vector3(direction.x, direction.y));

        if (Physics.Raycast(fpsCam.transform.position, direction, out hit, range))
        {
            Debug.Log(hit.transform.name);

            if (hit.collider.tag == "Robot")
            {
                Target target = hit.transform.GetComponent<Target>();
                if (target != null)
                {
                    target.TakeDamage(damage);
                }

                if (hit.rigidbody != null)
                {
                    hit.rigidbody.AddForce(-hit.normal * impactForce);
                }

                AmmoUpdate();
                GameObject impactGO = Instantiate(impactEffect, hit.point, Quaternion.LookRotation(hit.normal));
                Destroy(impactGO, 2f);
            }

            if (hit.collider.tag == "eye")
            {
                Target target = hit.transform.GetComponent<Target>();
                if (target != null)
                {
                    target.TakeDamage(damage * 3);
                }

                if (hit.rigidbody != null)
                {
                    hit.rigidbody.AddForce(-hit.normal * impactForce);
                }

                AmmoUpdate();
                GameObject impactGO = Instantiate(impactEffect, hit.point, Quaternion.LookRotation(hit.normal));
                Destroy(impactGO, 2f);
            }

        }
    }

    IEnumerator Melee()
    {
        fire = false;
        animator.SetBool("melee", true);
        RaycastHit hit;

        Vector3 direction = fpsCam.transform.forward * Time.deltaTime * 100;

        if (Physics.Raycast(fpsCam.transform.position, direction, out hit, 1))
        {
            Debug.Log(hit.transform.name);

            if (hit.collider.tag == "Robot")
            {
                Target target = hit.transform.GetComponent<Target>();
                if (target != null)
                {
                    target.TakeDamage(meleeDamage);
                }

                if (hit.rigidbody != null)
                {
                    hit.rigidbody.AddForce(-hit.normal * impactForce);
                }
            }
        }

        yield return new WaitForSeconds(.3f);

        animator.SetBool("melee", false);
    }

    IEnumerator Reload()
    {

        isReloading = true;
        animator.SetBool("aiming", false);

        Debug.Log("Reloading...");

        yield return new WaitForSeconds(.25f);

        animator.SetBool("reloading", true);

        ammoNeeded -= currentAmmo;

        if (PlayerInvantory.points <= ammoNeeded)
        {
            currentAmmo = PlayerInvantory.points;
            PlayerInvantory.points = 0;
        }
        else
        {          
            PlayerInvantory.points -= ammoNeeded;
            currentAmmo = clip;
        }
        

        yield return new WaitForSeconds(reloadTime -.25f);

        animator.SetBool("reloading", false);

        yield return new WaitForSeconds(.25f);      

        ammoNeeded = clip;

        AmmoUpdate();

        isReloading = false;       
    }

    public void AmmoUpdate()
    {
       ammoText.text = currentAmmo.ToString()+" :Ammo";
    }
}
