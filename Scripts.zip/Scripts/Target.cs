﻿using System.Collections;
using UnityEngine;
using EZCameraShake;

public class Target : MonoBehaviour
{
    public float health = 50f;
    public int gelDrop = 20;
    public int life = 1;
    public ParticleSystem death;

    public void TakeDamage(float amount)
    {
        health -= amount;
        if (health <= 0f)
        {
            StartCoroutine(Die());
        }
    }

    public IEnumerator Die()
    {
        death.Play();
        yield return new WaitForSeconds(.25f);
        Destroy(gameObject);
        Spawning.killCount += life;
        PlayerInvantory.points += gelDrop;
    }
}

