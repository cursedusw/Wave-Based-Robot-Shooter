﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Gun : MonoBehaviour
{
    public float lookRadius = 10f;

    Transform target;
    public float damage = 10;
    public float range = 100f;
    public float normalSpread = 0.04f;
    public float impactForce = 30f;
    public float fireRate = 15f;
    public ParticleSystem muzzleFlash_R;
    public ParticleSystem muzzleFlash_L;
    public GameObject impactEffect;
    public GameObject NPCCam;
    private float nextTimeToFire = 0f;
    public float shootCount;
    private float muzzleFlash = 0f;
    public AudioSource gunShoot;

    // Start is called before the first frame update
    void Start()
    {
        target = PlayerManager.instance.player.transform;
        gunShoot = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit see; // raycast for sight of the ai

        Vector3 direction = NPCCam.transform.forward;         


        if (Physics.Raycast(NPCCam.transform.position, direction, out see, range))
        {
            Debug.Log(see.transform.name);

            PlayerHealth player = see.transform.GetComponent<PlayerHealth>();
            if (player != null) //checks for the player
            {

                if (Time.time >= nextTimeToFire)
                {
                    nextTimeToFire = Time.time + 1f / fireRate;
                    Shoot(); // fires the guns
                }
            }
        }
    }

    void Shoot()
    {
        shootCount++; //for alternating guns left to right
        gunShoot.Play(); // sound

        if (muzzleFlash == 0f)
        {
            muzzleFlash_R.Play();
            muzzleFlash++;
        }
        else
        {
            muzzleFlash_L.Play();
            muzzleFlash = 0f;
        }

        RaycastHit hit;

        Vector3 direction = NPCCam.transform.forward; // Bullet Spread
        direction.x += Random.Range(-normalSpread, normalSpread);
        direction.y += Random.Range(-normalSpread, normalSpread);
        direction.z += Random.Range(-normalSpread, normalSpread);


        if (Physics.Raycast(NPCCam.transform.position, direction, out hit, range))
        {
            Debug.Log(hit.transform.name);

            PlayerHealth target = hit.transform.GetComponent<PlayerHealth>();

            if (target != null)//if for if it hits the player
            {
                target.TakeDamage(damage); //does the damage
            }

            if (hit.rigidbody != null)
            {
                hit.rigidbody.AddForce(-hit.normal * impactForce);
            }

            GameObject impactGO = Instantiate(impactEffect, hit.point, Quaternion.LookRotation(hit.normal));
            Destroy(impactGO, 1f);
            return;

        }
    }
}
