﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerControls : MonoBehaviour
{
    CharacterController cc;
    Rigidbody rb;
    public float speed = 10f;
    //gravity var
    public float ySpeed = 0;
    float gravity = -30;
    public Transform fpsCamera;
    float pitch = 0f;
    public float sprintSpeed;
    public float walkSpeed;
    float mouseSensetivity;
    public float aimSense = 2.5f;
    public float regSense = 5f;
    public static bool isGrounded;
    public int extraJump;
    public int jumpCount;
    public bool sprintAble;
    public bool jumpAble;
    public bool doubleJumpAble;
    public bool dashAble;
    public float dashForce;
    public float dash;
    public bool coolDown;
    public float coolDownRate;

    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = (false);
        cc = GetComponent<CharacterController>();
        rb = GetComponent<Rigidbody>();
        sprintAble = true;
        jumpAble = true;
        doubleJumpAble = false;
        dashAble = true;
    }

    // Update is called once per frame
    void Update()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = (false);
        //wasd in[ut controlls
        float xInput = Input.GetAxis("Horizontal") * (speed *= dash);
        float zInput = Input.GetAxis("Vertical") * speed;

        Vector3 move = new Vector3(xInput, 0, zInput);
        move = Vector3.ClampMagnitude(move, speed);
        move = transform.TransformVector(move);

        if (Input.GetKeyDown(KeyCode.Escape)) // takes you back to home screen
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
            Cursor.lockState = CursorLockMode.Confined;
            Cursor.visible = (true);
        }

        if (cc.isGrounded && jumpAble) //checks if you can jump
        {
            extraJump = jumpCount;
            isGrounded = true;
            if (Input.GetButtonDown("Jump"))// input check
            {
                Jump();
            }
            else
            {
                ySpeed = gravity * Time.deltaTime; //what brings you back down to the ground
            }
        }
        else
        {
            isGrounded = false;
            ySpeed += gravity * Time.deltaTime;
        }

        if (doubleJumpAble)
        {
            DoubleJump();
        }

        if (dashAble)
        {
            StartCoroutine(Dash());
        }

        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            mouseSensetivity = aimSense;
        }
        else
        {
            mouseSensetivity = regSense;
        }

        cc.Move((move + new Vector3(0, ySpeed, 0)) * Time.deltaTime);

        float xMouse = Input.GetAxis("Mouse X") * mouseSensetivity;
        transform.Rotate(0, xMouse, 0);

        pitch -= Input.GetAxis("Mouse Y") * mouseSensetivity;
        pitch = Mathf.Clamp(pitch, -85f, 85f);
        Quaternion camRotation = Quaternion.Euler(pitch, 0, 0);
        fpsCamera.localRotation = camRotation;

        if (sprintAble)
        {
            Sprint();
        }
    }
    void Jump()
    {
        ySpeed = 15f;
    }

    void DoubleJump()
    {
        if (isGrounded == false && extraJump >= 1)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                Jump();
                extraJump--;
            }
        }
    }

    void Sprint() //all the sprint code
    {
        if (Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.LeftShift))
        {
            speed = sprintSpeed;
        }

        else
        {
            speed = walkSpeed;
        }
    }

    IEnumerator Dash() //dash code
    {
        if (Input.GetKeyDown(KeyCode.LeftControl) && !coolDown)
        {            
            dash = dashForce;
            yield return new WaitForSeconds(.2f);
            coolDown = true;
            dash = 1;
            yield return new WaitForSeconds(coolDownRate);
            coolDown = false;
        }
    }
}
